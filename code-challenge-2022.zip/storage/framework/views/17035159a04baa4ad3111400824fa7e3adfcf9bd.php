
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <h1>Country Details of <?php echo e($name); ?></h1><hr/>
                    <?php
                     $year = date('Y');
                    $con_detail = json_decode(file_get_contents('https://date.nager.at/api/v3/CountryInfo/'.$code));
                    $holidays   = json_decode(file_get_contents('https://date.nager.at/api/v3/PublicHolidays/'.$year.'/'.$code.''));
                    $totalHolidays = count($holidays);
                     $borderC = count($con_detail->borders);
                    ?>
<!-- Country Details -->
                    <table class="table table-responsive table-hover" >
                        <thead>
                        <th>Country Name</th>
                            <th>Region</th>
                            <th>Code</th>
                            <th>No. of Border</th>
                            
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo e($con_detail->commonName); ?></td>
                                <td><?php echo e($con_detail->region); ?></td>
                                <td><?php echo e($con_detail->countryCode); ?></td>
                                <td><?php echo e($borderC); ?></td>
                            </tr>
                        </tbody>

                    </table>
                    <h1>4 holidays for the current year of <?php echo e($name); ?></h1><hr/>
                    <!-- Holidays -->
                    <table class="table table-responsive table-hover" >
                        <thead>
                        <th>1st holiday</th>
                            <th>2nd holiday</th>
                            <th>3rd holiday</th>
                            <th>4th holiday</th>
                            <th>Total Holidays</th>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo e($holidays[0]->name); ?> / <?php echo e($holidays[0]->date); ?></td>
                                <td><?php echo e($holidays[1]->name); ?> / <?php echo e($holidays[0]->date); ?></td>
                                <td><?php echo e($holidays[2]->name); ?> / <?php echo e($holidays[0]->date); ?></td>
                                <td><?php echo e($holidays[3]->name); ?> / <?php echo e($holidays[0]->date); ?></td>
                                <td><?php echo e($totalHolidays); ?></td>
                            </tr>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>
               
<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cgtest\code-challenge-2022\resources\views/details.blade.php ENDPATH**/ ?>