
</body>
</html>


</script><?php /**PATH C:\xampp\htdocs\cgtest\code-challenge-2022\resources\views/inc/footer.blade.php ENDPATH**/ ?>